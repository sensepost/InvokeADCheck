﻿---
Module Name: InvokeADCheck
Module Guid: 0f4009c1-dc52-4f4a-b876-01bff266dd19
Download Help Link: https://github.com/sensepost/InvokeADCheck/release/InvokeADCheck/docs/InvokeADCheck.md
Help Version: 0.0.1
Locale: en-US
---

# InvokeADCheck Module
## Description
PowerShell module to check the security of Active Directory

## InvokeADCheck Cmdlets
### [Invoke-ADCheck](Invoke-ADCheck.md)
Performs various checks against the target Active Directory environment and outputs the results.


