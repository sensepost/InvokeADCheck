﻿---
Module Name: ADChecks
Module Guid: 0f4009c1-dc52-4f4a-b876-01bff266dd19
Download Help Link: https://github.com/ocd-nl/ADChecks/release/ADChecks/docs/ADChecks.md
Help Version: 0.0.1
Locale: en-US
---

# ADChecks Module
## Description
PowerShell module to check the security of Active Directory

## ADChecks Cmdlets
### [Invoke-ADCheck](Invoke-ADCheck.md)
TBD


